from sqlalchemy import Column, Integer, String, create_engine, declarative_base

Base = declarative_base()

class Frame(Base):
    __tablename__ = 'frames'
    id = Column(Integer, primary_key=True)
    name = Column(String, nullable=False)
    price = Column(String, nullable=False)
    image = Column(String, nullable=False)
    description = Column(String, nullable=False)

engine = create_engine('sqlite:///data/frames.db')
Base.metadata.create_all(engine)
