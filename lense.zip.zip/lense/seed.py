from models import Frame, session

# Sample frames
def seed_data():
frames = [
    Frame(name="Classic Frame", price="$50", image="/static/classic-frame.jpg", description="A timeless classic."),
    Frame(name="Modern Frame", price="$70", image="/static/modern-frame.jpg", description="Sleek and modern."),
    Frame(name="Sporty Frame", price="$80", image="/static/sporty-frame.jpg", description="Perfect for active lifestyles."),
]

# Add and commit to the database
session.add_all(frames)
session.commit()
print("Frames added successfully!")
if __name__=="__main__":
    seed_data()