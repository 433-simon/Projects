fetch('http://127.0.0.1:5000/frames')
  .then(response => response.json())
  .then(data => {
    const gallery = document.getElementById('product-gallery');
    data.forEach(frame => {
      const card = document.createElement('div');
      card.classList.add('product-card');
      card.innerHTML = `
        <img src="${frame.image}" alt="${frame.name}">
        <h3>${frame.name}</h3>
        <p>${frame.price}</p>
        <p>${frame.description}</p>
      `;
      gallery.appendChild(card);
    });
  })
  .catch(err => console.error(err));
  const products = [
    {
      id: 1,
      name: "Classic Frame",
      price: "$50",
      image: "images/classic-frame.jpg",
      description: "A timeless classic."
    },
    {
      id: 2,
      name: "Modern Frame",
      price: "$70",
      image: "images/modern-frame.jpg",
      description: "Sleek and modern."
    },
    {
      id: 3,
      name: "Sporty Frame",
      price: "$80",
      image: "images/sporty-frame.jpg",
      description: "Perfect for active lifestyles."
    }
  ];
  const searchInput = document.getElementById('search');

searchInput.addEventListener('input', (e) => {
  const query = e.target.value.toLowerCase();
  document.querySelectorAll('.product-card').forEach(card => {
    const name = card.querySelector('h3').textContent.toLowerCase();
    card.style.display = name.includes(query) ? '' : 'none';
  });
});

  
  const gallery = document.getElementById('product-gallery');
  
  products.forEach(product => {
    const card = document.createElement('div');
    card.classList.add('product-card');
    card.innerHTML = `
      <img src="${product.image}" alt="${product.name}">
      <h3>${product.name}</h3>
      <p>${product.price}</p>
      <p>${product.description}</p>
    `;
    gallery.appendChild(card);
  });
  