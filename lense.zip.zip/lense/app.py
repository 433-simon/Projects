from flask import Flask
from models import Frame, session

app = Flask(__name__)

# Define seed_data function
def seed_data():
    frames = [
        Frame(name="Classic Frame", price="$50", image="/static/classic-frame.jpg", description="A timeless classic."),
        Frame(name="Modern Frame", price="$70", image="/static/modern-frame.jpg", description="Sleek and modern."),
        Frame(name="Sporty Frame", price="$80", image="/static/sporty-frame.jpg", description="Perfect for active lifestyles."),
    ]
    session.add_all(frames)
    session.commit()
    print("Database seeded successfully!")

# Run the app and seed the data
if __name__ == "__main__":
    seed_data()  # Seed the database
    app.run(debug=True)


    
