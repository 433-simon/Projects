<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get form data
    $name = htmlspecialchars($_POST['name']);
    $email = htmlspecialchars($_POST['email']);
    $message = htmlspecialchars($_POST['message']);

    // Simulate sending the form data (you can later store this in a database or send it via email)
    // For now, we just display the submitted data for confirmation
    echo "<h1>Thank you for reaching out!</h1>";
    echo "<p>Your form has been successfully submitted! We will get back to you shortly.</p>";
    echo "<p><strong>Name:</strong> " . $name . "</p>";
    echo "<p><strong>Email:</strong> " . $email . "</p>";
    echo "<p><strong>Message:</strong> " . $message . "</p>";

    // Optionally, you can redirect after a few seconds to prevent the form from being resubmitted
    header("refresh:5;url=index.html"); // Redirect back to homepage after 5 seconds
    exit;
} else {
    // If the form wasn't submitted via POST, redirect back to the contact page
    header("Location: contact.html");
    exit;
}
?>
