from sqlalchemy import Column, Integer, String, create_engine
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker

# Define Base and Engine
Base = declarative_base()
engine = create_engine('sqlite:///data/frames.db', echo=True)

# Define Frame Model
class Frame(Base):
    __tablename__ = 'frames'
    id = Column(Integer, primary_key=True, autoincrement=True)
    name = Column(String, nullable=False)
    price = Column(String, nullable=False)
    image = Column(String, nullable=False)
    description = Column(String, nullable=False)

# Create the table
Base.metadata.create_all(engine)

# Create a session
Session = sessionmaker(bind=engine)
session = Session()


